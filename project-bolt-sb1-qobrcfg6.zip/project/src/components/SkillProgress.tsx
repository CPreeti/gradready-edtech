import { CheckCircle2, Circle, Lock, Zap } from 'lucide-react';

interface Milestone {
  id: number;
  title: string;
  description: string;
  completed: boolean;
}

interface SkillProgressProps {
  skillName: string;
  progress: number;
  milestones: Milestone[];
  proficiencyLevel: 'beginner' | 'intermediate' | 'advanced';
}

const proficiencyColors = {
  beginner: 'from-blue-400 to-blue-600',
  intermediate: 'from-purple-400 to-purple-600',
  advanced: 'from-emerald-400 to-emerald-600',
};

const proficiencyLabels = {
  beginner: 'Beginner',
  intermediate: 'Intermediate',
  advanced: 'Advanced',
};

export default function SkillProgress({
  skillName,
  progress,
  milestones,
  proficiencyLevel,
}: SkillProgressProps) {
  const completedMilestones = milestones.filter(m => m.completed).length;

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-lg border border-gray-200 dark:border-gray-800 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            {skillName}
          </h3>
          <div className="flex items-center gap-2">
            <Zap size={16} className="text-amber-500" />
            <span className={`text-sm font-semibold bg-gradient-to-r ${proficiencyColors[proficiencyLevel]} bg-clip-text text-transparent`}>
              {proficiencyLabels[proficiencyLevel]}
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-gray-900 dark:text-white">
            {progress}%
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {completedMilestones} of {milestones.length} done
          </p>
        </div>
      </div>

      <div className="mb-6">
        <div className="h-3 bg-gray-200 dark:bg-gray-800 rounded-full overflow-hidden">
          <div
            className={`h-full bg-gradient-to-r ${proficiencyColors[proficiencyLevel]} transition-all duration-500`}
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="space-y-3">
        {milestones.map((milestone) => (
          <div
            key={milestone.id}
            className={`flex items-start gap-3 p-3 rounded-lg transition-colors ${
              milestone.completed
                ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800'
                : 'bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700'
            }`}
          >
            <div className="flex-shrink-0 mt-1">
              {milestone.completed ? (
                <CheckCircle2 size={20} className="text-green-600 dark:text-green-400" />
              ) : (
                <Circle size={20} className="text-gray-400 dark:text-gray-600" />
              )}
            </div>
            <div className="flex-1">
              <p className={`font-medium ${
                milestone.completed
                  ? 'text-green-900 dark:text-green-300'
                  : 'text-gray-900 dark:text-white'
              }`}>
                {milestone.title}
              </p>
              <p className={`text-sm ${
                milestone.completed
                  ? 'text-green-700 dark:text-green-400'
                  : 'text-gray-600 dark:text-gray-400'
              }`}>
                {milestone.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
