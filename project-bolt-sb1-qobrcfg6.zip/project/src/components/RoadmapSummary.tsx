import { TrendingUp, Calendar, CheckCircle2, Clock } from 'lucide-react';

interface RoadmapStats {
  totalSkills: number;
  skillsCompleted: number;
  estimatedDuration: string;
  nextMilestone: string;
}

interface RoadmapSummaryProps {
  stats: RoadmapStats;
}

export default function RoadmapSummary({ stats }: RoadmapSummaryProps) {
  const progressPercentage = Math.round(
    (stats.skillsCompleted / stats.totalSkills) * 100
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-900/40 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
        <div className="flex items-center justify-between mb-4">
          <TrendingUp className="text-blue-600 dark:text-blue-400" size={24} />
          <span className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {progressPercentage}%
          </span>
        </div>
        <p className="text-sm text-blue-700 dark:text-blue-300 font-medium">
          Overall Progress
        </p>
      </div>

      <div className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-900/40 rounded-xl p-6 border border-purple-200 dark:border-purple-800">
        <div className="flex items-center justify-between mb-4">
          <CheckCircle2 className="text-purple-600 dark:text-purple-400" size={24} />
          <span className="text-3xl font-bold text-purple-600 dark:text-purple-400">
            {stats.skillsCompleted}/{stats.totalSkills}
          </span>
        </div>
        <p className="text-sm text-purple-700 dark:text-purple-300 font-medium">
          Skills Mastered
        </p>
      </div>

      <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-900/40 rounded-xl p-6 border border-emerald-200 dark:border-emerald-800">
        <div className="flex items-center justify-between mb-4">
          <Calendar className="text-emerald-600 dark:text-emerald-400" size={24} />
          <span className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
            {stats.estimatedDuration}
          </span>
        </div>
        <p className="text-sm text-emerald-700 dark:text-emerald-300 font-medium">
          Duration
        </p>
      </div>

      <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-900/40 rounded-xl p-6 border border-amber-200 dark:border-amber-800">
        <div className="flex items-center justify-between mb-4">
          <Clock className="text-amber-600 dark:text-amber-400" size={24} />
        </div>
        <p className="text-sm text-amber-700 dark:text-amber-300 font-medium">
          Next: {stats.nextMilestone}
        </p>
      </div>
    </div>
  );
}
