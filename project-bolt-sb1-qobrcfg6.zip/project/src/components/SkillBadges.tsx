import { Trophy, Star, Zap, Target, BookOpen, Flame } from 'lucide-react';

interface Badge {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  unlocked: boolean;
  progress: number;
  requirement: string;
}

interface SkillBadgesProps {
  skillsCompleted: number;
  totalSkills: number;
  projectsCompleted: number;
  certificationsEarned: number;
}

export default function SkillBadges({
  skillsCompleted,
  totalSkills,
  projectsCompleted,
  certificationsEarned,
}: SkillBadgesProps) {
  const badges: Badge[] = [
    {
      id: 'syllabus-explorer',
      title: 'Syllabus Explorer',
      description: 'Uploaded and analyzed your first syllabus',
      icon: <BookOpen className="w-8 h-8" />,
      unlocked: totalSkills > 0,
      progress: totalSkills > 0 ? 100 : 0,
      requirement: 'Upload syllabus',
    },
    {
      id: 'skill-starter',
      title: 'Skill Starter',
      description: 'Completed first skill milestone',
      icon: <Star className="w-8 h-8" />,
      unlocked: skillsCompleted >= 1,
      progress: skillsCompleted > 0 ? 100 : 0,
      requirement: '1 skill completed',
    },
    {
      id: 'project-builder',
      title: 'Project Builder',
      description: 'Completed your first project',
      icon: <Zap className="w-8 h-8" />,
      unlocked: projectsCompleted >= 1,
      progress: projectsCompleted > 0 ? 100 : 0,
      requirement: '1 project done',
    },
    {
      id: 'industry-builder',
      title: 'Industry Builder',
      description: 'Mastered 5+ professional skills',
      icon: <Target className="w-8 h-8" />,
      unlocked: skillsCompleted >= 5,
      progress: Math.min(100, (skillsCompleted / 5) * 100),
      requirement: '5 skills mastered',
    },
    {
      id: 'certified-pro',
      title: 'Certified Pro',
      description: 'Earned your first professional certification',
      icon: <Trophy className="w-8 h-8" />,
      unlocked: certificationsEarned >= 1,
      progress: certificationsEarned > 0 ? 100 : 0,
      requirement: '1 certification earned',
    },
    {
      id: 'roadmap-master',
      title: 'Roadmap Master',
      description: 'Completed entire learning roadmap',
      icon: <Flame className="w-8 h-8" />,
      unlocked: skillsCompleted === totalSkills && totalSkills > 0,
      progress: totalSkills > 0 ? (skillsCompleted / totalSkills) * 100 : 0,
      requirement: 'Complete all skills',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {badges.map((badge) => (
          <div
            key={badge.id}
            className={`rounded-2xl p-6 border-2 transition-all duration-300 ${
              badge.unlocked
                ? 'bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 border-blue-300 dark:border-blue-700'
                : 'bg-gray-100 dark:bg-gray-800 border-gray-300 dark:border-gray-700 opacity-50'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div
                className={`p-3 rounded-lg ${
                  badge.unlocked
                    ? 'bg-gradient-to-br from-blue-400 to-purple-500 text-white'
                    : 'bg-gray-300 dark:bg-gray-600 text-gray-500'
                }`}
              >
                {badge.icon}
              </div>
              {badge.unlocked && (
                <span className="text-xl">✨</span>
              )}
            </div>

            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
              {badge.title}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              {badge.description}
            </p>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-gray-600 dark:text-gray-400">
                  {badge.requirement}
                </span>
                <span className="text-xs font-bold text-gray-900 dark:text-white">
                  {Math.round(badge.progress)}%
                </span>
              </div>
              <div className="h-2 bg-gray-300 dark:bg-gray-700 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-500 ${
                    badge.unlocked
                      ? 'bg-gradient-to-r from-blue-400 to-purple-500'
                      : 'bg-gray-400'
                  }`}
                  style={{ width: `${badge.progress}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
