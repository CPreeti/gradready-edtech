import { Sparkles } from 'lucide-react';

interface HeroProps {
  studentName?: string;
}

export default function Hero({ studentName = 'Student' }: HeroProps) {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white shadow-xl">
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-6 h-6" />
        <span className="text-sm font-semibold uppercase tracking-wider">Your Journey Starts Here</span>
      </div>
      <h2 className="text-4xl font-bold mb-2">
        Welcome {studentName}
      </h2>
      <p className="text-xl text-blue-100">
        Let's map your career and unlock your potential.
      </p>
    </div>
  );
}
