import { ArrowRight, BookOpen, Code2, Target } from 'lucide-react';

interface PathPhase {
  phase: number;
  title: string;
  duration: string;
  topics: string[];
  resources: string[];
}

interface LearningPathProps {
  skillName: string;
  phases: PathPhase[];
  certification?: string;
}

export default function LearningPath({
  skillName,
  phases,
  certification,
}: LearningPathProps) {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-800">
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          {skillName}
        </h3>
        <p className="text-gray-600 dark:text-gray-400">
          Structured learning path to master this skill
        </p>
      </div>

      {certification && (
        <div className="mb-8 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <Target size={18} className="text-blue-600 dark:text-blue-400" />
            <p className="font-semibold text-blue-900 dark:text-blue-300">Certification Target</p>
          </div>
          <p className="text-sm text-blue-800 dark:text-blue-200">{certification}</p>
        </div>
      )}

      <div className="space-y-6">
        {phases.map((phase, index) => (
          <div key={phase.phase}>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold text-sm">
                  {phase.phase}
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-2 mb-2">
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white">
                    {phase.title}
                  </h4>
                  <span className="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
                    {phase.duration}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Code2 size={16} className="text-gray-600 dark:text-gray-400" />
                      <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                        Topics
                      </p>
                    </div>
                    <ul className="space-y-1">
                      {phase.topics.map((topic, i) => (
                        <li
                          key={i}
                          className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2"
                        >
                          <span className="w-1.5 h-1.5 bg-blue-400 rounded-full" />
                          {topic}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <BookOpen size={16} className="text-gray-600 dark:text-gray-400" />
                      <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                        Resources
                      </p>
                    </div>
                    <ul className="space-y-1">
                      {phase.resources.map((resource, i) => (
                        <li
                          key={i}
                          className="text-sm text-gray-600 dark:text-gray-400 flex items-center gap-2"
                        >
                          <span className="w-1.5 h-1.5 bg-purple-400 rounded-full" />
                          {resource}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {index < phases.length - 1 && (
              <div className="flex justify-center py-4">
                <ArrowRight size={20} className="text-gray-300 dark:text-gray-700 rotate-90" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
