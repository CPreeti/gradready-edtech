import { Upload, FileText } from 'lucide-react';
import { useState, useRef } from 'react';

// Updated to accept onUpload and isLoading props
export default function UploadCard({ onUpload, isLoading }: { onUpload: () => void, isLoading: boolean }) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      setUploadedFile(files[0]);
      // Automatically trigger the upload logic from App.tsx when file is dropped
      onUpload();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setUploadedFile(files[0]);
      // Automatically trigger the upload logic from App.tsx when file is selected
      onUpload();
    }
  };

  const handleClick = () => {
    if (!isLoading) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl p-6 shadow-lg border border-gray-200 dark:border-gray-800">
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
        Upload Your Syllabus
      </h3>
      <p className="text-gray-600 dark:text-gray-400 mb-6">
        Share your course syllabus and we'll generate a personalized learning roadmap tailored to your goals.
      </p>

      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
        className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
          isLoading ? 'cursor-not-allowed opacity-60' : 'cursor-pointer hover:border-blue-500'
        } ${isDragging ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-300 dark:border-gray-700'}`}
      >
        <div className="flex flex-col items-center gap-3">
          {uploadedFile ? (
            <FileText className="size-12 text-blue-500" />
          ) : (
            <Upload className="size-12 text-gray-400" />
          )}
          <p className="text-gray-700 dark:text-gray-300 font-medium">
            {isLoading ? "Analyzing your syllabus..." : uploadedFile ? uploadedFile.name : "Drag & Drop or Click to Upload"}
          </p>
        </div>
        
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileSelect} 
          className="hidden" 
          accept=".pdf,.doc,.docx,.txt"
          disabled={isLoading}
        />
      </div>
    </div>
  );
}