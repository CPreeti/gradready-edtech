import { ChevronRight } from 'lucide-react';

interface SkillCardProps {
  title: string;
  project: string;
}

export default function SkillCard({ title, project }: SkillCardProps) {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-800 hover:shadow-xl hover:border-blue-400 dark:hover:border-blue-500 transition-all duration-300">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            {title}
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {project}
          </p>
          <button className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white rounded-lg font-medium transition-all duration-300">
            View Details
            <ChevronRight size={16} />
          </button>
        </div>
        <div className="flex-shrink-0">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-xl flex items-center justify-center text-white text-2xl font-bold">
            {title.charAt(0)}
          </div>
        </div>
      </div>
    </div>
  );
}
