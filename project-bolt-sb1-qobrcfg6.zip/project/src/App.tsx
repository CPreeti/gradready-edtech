import { useState } from 'react';
import data from './data/masterData.json';
import Sidebar from './components/Sidebar';
import Hero from './components/Hero';
import UploadCard from './components/UploadCard';
import ThemeToggle from './components/ThemeToggle';
import SkillCard from './components/SkillCard';
import SkillProgress from './components/SkillProgress';
import LearningPath from './components/LearningPath';
import RoadmapSummary from './components/RoadmapSummary';
import SkillBadges from './components/SkillBadges';
import SignupPage from './components/SignupPage';
import type { StudentData } from './components/SignupPage';

function App() {
  const [isSignedUp, setIsSignedUp] = useState(false);
  const [studentData, setStudentData] = useState<StudentData | null>(null);
  const [activeTab, setActiveTab] = useState('upload');
  const [isAnalyzed, setIsAnalyzed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSignup = (userData: StudentData) => {
    setStudentData(userData);
    setIsSignedUp(true);
  };

  const handleUpload = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsAnalyzed(true);
      setIsLoading(false);
    }, 2000);
  };

  if (!isSignedUp) {
    return <SignupPage onSignupComplete={handleSignup} />;
  }

  return (
    <div className="flex min-h-screen bg-gray-50 dark:bg-gray-950">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <main className="flex-1 p-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex justify-end mb-6">
            <ThemeToggle />
          </div>

          <Hero studentName={studentData?.fullName || 'Student'} />

          <div className="mt-8 grid gap-6">
            {activeTab === 'upload' && (
              <UploadCard onUpload={handleUpload} isLoading={isLoading} />
            )}

            {activeTab === 'roadmap' && (
              <div className="grid gap-6">
                {!isAnalyzed ? (
                  <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg border border-gray-200 dark:border-gray-800 text-center">
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                      Waiting for Syllabus
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      Upload your syllabus in the 'Upload' tab to generate your personalized learning roadmap.
                    </p>
                  </div>
                ) : (
                  <>
                    <RoadmapSummary
                      stats={{
                        totalSkills: data.length,
                        skillsCompleted: Math.floor(data.length / 2),
                        estimatedDuration: '12-16 weeks',
                        nextMilestone: data[0]?.skill || 'Next Skill',
                      }}
                    />

                    <div className="space-y-6">
                      {data.map((item: any, index: number) => (
                        <div key={index} className="grid gap-6">
                          <SkillProgress
                            skillName={item.skill}
                            progress={Math.min(100, (index + 1) * 25)}
                            proficiencyLevel={index === 0 ? 'advanced' : index === 1 ? 'intermediate' : 'beginner'}
                            milestones={[
                              {
                                id: 1,
                                title: 'Learn Fundamentals',
                                description: 'Master core concepts and theory',
                                completed: index < 2,
                              },
                              {
                                id: 2,
                                title: 'Complete ' + item.project.title,
                                description: 'Build a real-world project',
                                completed: index === 0,
                              },
                              {
                                id: 3,
                                title: 'Achieve ' + (item.certification?.entry || 'Entry Certification'),
                                description: 'Pass the certification exam',
                                completed: false,
                              },
                            ]}
                          />

                          <LearningPath
                            skillName={item.skill}
                            certification={item.certification?.advanced}
                            phases={[
                              {
                                phase: 1,
                                title: 'Foundation Building',
                                duration: '4 weeks',
                                topics: [
                                  'Core concepts',
                                  'Best practices',
                                  'Industry standards',
                                ],
                                resources: [
                                  'Online courses',
                                  'Documentation',
                                  'Tutorials',
                                ],
                              },
                              {
                                phase: 2,
                                title: 'Practical Application',
                                duration: '6 weeks',
                                topics: [
                                  'Hands-on projects',
                                  'Real-world scenarios',
                                  'Problem solving',
                                ],
                                resources: [
                                  item.project.tool,
                                  'Code labs',
                                  'GitHub repos',
                                ],
                              },
                              {
                                phase: 3,
                                title: 'Mastery & Certification',
                                duration: '3-4 weeks',
                                topics: [
                                  'Advanced concepts',
                                  'Exam preparation',
                                  'Interview prep',
                                ],
                                resources: [
                                  'Practice tests',
                                  'Study guides',
                                  'Mentorship',
                                ],
                              },
                            ]}
                          />
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            {activeTab === 'badges' && (
              <SkillBadges
                skillsCompleted={isAnalyzed ? Math.floor(data.length / 2) : 0}
                totalSkills={data.length}
                projectsCompleted={isAnalyzed ? Math.floor(data.length / 2) : 0}
                certificationsEarned={isAnalyzed ? 1 : 0}
              />
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;